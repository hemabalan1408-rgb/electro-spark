from flask import Flask, request, jsonify
from flask_cors import CORS
from nlp_engine import get_legal_response, get_all_categories
from translator import (
    translate_to_english,
    translate_response,
    get_supported_languages,
    detect_language
)

app = Flask(__name__)
CORS(app)  # Allow React frontend to connect


@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "message": "Electro Spark Legal Assistant API",
        "status": "running",
        "version": "1.0.0"
    })


@app.route("/chat", methods=["POST"])
def chat():
    """
    Main chat endpoint.
    Receives user message, detects language,
    translates to English, finds legal answer,
    translates back to user's language.
    """
    data = request.get_json()

    if not data or "message" not in data:
        return jsonify({"error": "No message provided"}), 400

    user_message = data.get("message", "").strip()
    selected_lang = data.get("language", "auto")  # Language selected by user

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    try:
        # Step 1: Detect or use selected language
        if selected_lang == "auto":
            detected_lang = detect_language(user_message)
        else:
            detected_lang = selected_lang

        # Step 2: Translate to English for processing
        english_text, source_lang = translate_to_english(user_message)

        # Use detected_lang if auto, else use selected_lang
        response_lang = detected_lang if selected_lang == "auto" else selected_lang

        # Step 3: Get legal response in English
        english_response = get_legal_response(english_text, user_message)

        # Step 4: Translate response back to user's language
        final_response = translate_response(english_response, response_lang)

        return jsonify({
            "response": final_response,
            "detected_language": response_lang,
            "english_query": english_text,
            "status": "success"
        })

    except Exception as e:
        return jsonify({
            "response": "Sorry, I encountered an error. Please try again or call Legal Aid: 1516",
            "status": "error",
            "error": str(e)
        }), 500


@app.route("/languages", methods=["GET"])
def languages():
    """Return list of supported languages."""
    return jsonify(get_supported_languages())


@app.route("/categories", methods=["GET"])
def categories():
    """Return available legal categories."""
    cats = get_all_categories()
    formatted = {c.replace("_", " ").title(): c for c in cats}
    return jsonify(formatted)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy", "service": "Electro Spark API"})


if __name__ == "__main__":
    print("🚀 Electro Spark Legal Assistant API starting...")
    print("📡 Running at http://localhost:5000")
    app.run(debug=True, port=5000)
