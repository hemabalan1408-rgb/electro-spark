# ⚡ Electro Spark — Setup Guide

## Project Structure
```
NIRAL_PROJECT/
├── backend/
│   ├── app.py           ← Flask API server
│   ├── nlp_engine.py    ← Legal query matching
│   ├── translator.py    ← Regional language translation
│   ├── legal_db.json    ← Legal knowledge base
│   └── requirements.txt
└── frontend/
    └── index.html       ← Chat UI (open in browser)
```

## Step 1 — Install Python Dependencies
```bash
cd backend
pip install -r requirements.txt
```

## Step 2 — Start Backend Server
```bash
python app.py
```
✅ Backend runs at: http://localhost:5000

## Step 3 — Open Frontend
Just open `frontend/index.html` in your browser.
No server needed for frontend!

## Step 4 — Test It
Type these queries to test:
- "What are my land rights?"
- "என் நில உரிமை என்ன?"  (Tamil)
- "How to file an FIR?"
- "minimum wage Tamil Nadu"
- "domestic violence complaint"

## Legal Categories Supported
1. 🏡 Land Rights
2. 👷 Labor Rights
3. 🛡️ Women Rights
4. 🛒 Consumer Rights
5. 🏛️ Government Schemes
6. 🚔 Criminal Law
7. 👨‍👩‍👧 Family Law

## Languages Supported
- Tamil (தமிழ்)
- Hindi (हिंदी)
- Telugu (తెలుగు)
- Kannada (ಕನ್ನಡ)
- Malayalam (മലയാളം)
- English

## Emergency Contacts
- Police: 100
- Women Helpline: 181
- Free Legal Aid: 1516
- Cyber Crime: 1930
- Consumer Helpline: 1915
