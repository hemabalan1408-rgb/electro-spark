import json
import os
from difflib import SequenceMatcher

# Load legal database
DB_PATH = os.path.join(os.path.dirname(__file__), "legal_db.json")
with open(DB_PATH, "r", encoding="utf-8") as f:
    LEGAL_DB = json.load(f)


def similarity(a, b):
    """Calculate string similarity ratio."""
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def find_category(text):
    """Find the best matching category for the input text."""
    text_lower = text.lower()
    best_category = None
    best_score = 0

    for category, data in LEGAL_DB["categories"].items():
        score = 0
        for keyword in data["keywords"]:
            if keyword.lower() in text_lower:
                score += 2  # Direct keyword match
            elif similarity(keyword, text_lower) > 0.7:
                score += 1  # Similar keyword match
        if score > best_score:
            best_score = score
            best_category = category

    return best_category if best_score > 0 else None


def find_best_answer(text, category):
    """Find the best matching Q&A within a category."""
    if not category:
        return None

    qa_list = LEGAL_DB["categories"][category]["qa"]
    best_answer = None
    best_score = 0

    for qa in qa_list:
        score = similarity(text, qa["question"])
        # Also check keyword overlap
        text_words = set(text.lower().split())
        question_words = set(qa["question"].lower().split())
        overlap = len(text_words & question_words) / max(len(question_words), 1)
        combined_score = (score + overlap) / 2

        if combined_score > best_score:
            best_score = combined_score
            best_answer = qa["answer"]

    return best_answer


def get_legal_response(translated_text, original_text=""):
    """
    Main function to get legal response for a query.
    Returns answer string or fallback message.
    """
    text = translated_text.strip()

    # Check for greetings
    greetings = ["hello", "hi", "help", "start", "vanakkam", "வணக்கம்"]
    if any(g in text.lower() for g in greetings):
        return LEGAL_DB["general_responses"]["greeting"]

    # Check for emergency keywords
    emergency_words = ["emergency", "danger", "urgent", "help me now", "immediately"]
    if any(e in text.lower() for e in emergency_words):
        return LEGAL_DB["general_responses"]["emergency"]

    # Find category
    category = find_category(text)

    # Find best answer
    answer = find_best_answer(text, category)

    if answer:
        return answer
    elif category:
        # Return first answer in category as general help
        return LEGAL_DB["categories"][category]["qa"][0]["answer"]
    else:
        return LEGAL_DB["general_responses"]["not_found"]


def get_all_categories():
    """Return list of available legal categories."""
    return list(LEGAL_DB["categories"].keys())
