from googletrans import Translator, LANGUAGES

translator = Translator()

# Supported languages mapping
SUPPORTED_LANGUAGES = {
    "ta": "Tamil (தமிழ்)",
    "hi": "Hindi (हिंदी)",
    "te": "Telugu (తెలుగు)",
    "kn": "Kannada (ಕನ್ನಡ)",
    "ml": "Malayalam (മലയാളം)",
    "mr": "Marathi (मराठी)",
    "bn": "Bengali (বাংলা)",
    "gu": "Gujarati (ગુજરાતી)",
    "en": "English"
}


def detect_language(text):
    """Detect the language of input text."""
    try:
        detected = translator.detect(text)
        return detected.lang
    except Exception:
        return "en"  # Default to English on failure


def translate_to_english(text):
    """Translate any regional language text to English."""
    try:
        detected_lang = detect_language(text)
        if detected_lang == "en":
            return text, "en"
        result = translator.translate(text, src=detected_lang, dest="en")
        return result.text, detected_lang
    except Exception:
        return text, "en"  # Return original on failure


def translate_from_english(text, target_lang):
    """Translate English text to target regional language."""
    try:
        if target_lang == "en":
            return text
        result = translator.translate(text, src="en", dest=target_lang)
        return result.text
    except Exception:
        return text  # Return English on failure


def translate_response(english_response, target_lang):
    """
    Full translation pipeline:
    Translate English legal response to user's regional language.
    Falls back to English if translation fails.
    """
    if target_lang == "en":
        return english_response
    try:
        translated = translate_from_english(english_response, target_lang)
        return translated
    except Exception:
        return english_response  # Fallback to English


def get_supported_languages():
    """Return supported language options."""
    return SUPPORTED_LANGUAGES
